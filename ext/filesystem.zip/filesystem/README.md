#### filesystem/path.h: A simple class for manipulating paths on Linux/Windows/Mac OS
 
This class is just a temporary workaround to avoid the heavy boost dependency
until `boost::filesystem` is integrated into the standard template library at
some point in the future.
