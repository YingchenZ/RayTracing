
void testNormalizedConversionError ();
void testDenormalizedConversionError ();
void testRoundingError ();

