Blender Plugin for Nori by Adrien Gruson
-> http://people.irisa.fr/Adrien.Gruson/biskra_2012.html

Installation
First, you must download a fairly recent version of Blender. They can be
downloaded from the official website (https://www.blender.org/).

To install, you must copy it to the scripts/addons folder of your blender installation.
On Linux, the default location is in "/usr/lib/blender/scripts/addons", and
on MacOS, it is in /Applications/blender.app/Contents/Resources/<version>/scripts/addons"

Adrien Gruson recorded a video with visual instructions on using the plugin.
It is in French, though the main concepts should be understandable even without
narration.

-> http://www.youtube.com/watch?list=UUb_VXTBD3haz-P7P0f_Bi8A&v=RHCwKJPDPjs


