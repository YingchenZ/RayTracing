#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 150
#error Unexpected pugixml version
#endif
